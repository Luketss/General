﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using CamadaDeDados;
using System.Data;

namespace RedeSocial.BLL
{
    public class ClienteBLL
    {
        DAL objDAL = new DAL();

        public int ID { get; set; }
        public string Nome { get; set; }
        public DateTime DataNascimento { get; set; }
        public string Email { get; set; }
        public string Senha { get; set; }
        
        public bool ValidarLogin(string email, string senha)
        {
            objDAL.Conectar();
            string sql = String.Format("SELECT id, nome FROM USUARIO WHERE EMAIL ='{0}' AND SENHA = '{1}'", email, senha);
            DataTable data = objDAL.RetDataTable(sql);

            if (data.Rows.Count == 1)
            {
                System.Web.HttpContext.Current.Session.Add("logado", true);
                System.Web.HttpContext.Current.Session.Add("id_usuario", data.Rows[0]["id"].ToString());
                System.Web.HttpContext.Current.Session.Add("nome_usuario", data.Rows[0]["nome"].ToString());
                return true;
            }
            else
            {
                System.Web.HttpContext.Current.Session.Add("logado", false);
                return false;
            }
        }
            public void Registrar()
            {
                objDAL.Conectar();
                string sql = String.Format("insert into USUARIO(nome,data_nascimento,email,senha) values('{0}','{1}','{2}','{3}')", Nome, DataNascimento.ToString("yyyy/MM/dd"), Email, Senha);
                objDAL.ExecutarComandoSQL(sql);
            }
        }
    }
